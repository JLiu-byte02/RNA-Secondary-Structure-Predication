# Error analysis summary

Generated: 2026-10-30T00:53:25+08:00 by `scripts/analysis/error_analysis.py`.

| run | method | family | n | ref stems | exact | trunc | frag | missing | spurious stems | FP | FN | RNA-macro F1 | BPP(FP) | BPP(FN) | Wilcoxon p |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| exp003b_5s_official_bpp_s17 | wide2d_bpp | 5s | 1283 | 11230 | 6906 | 1235 | 36 | 3053 | 441 | 2429 | 7569 | 0.8716 | 0.6888 | 0.2044 | 0.0000 |
| exp005c_srp_bpp_lrfix | wide2d_bpp | srp | 918 | 13074 | 4419 | 2110 | 178 | 6367 | 2637 | 7863 | 21120 | 0.6654 | 0.5851 | 0.2845 | 0.0000 |
| exp003a_5s_official_control_s17 | wide2d_control | 5s | 1283 | 11230 | 6181 | 1301 | 28 | 3720 | 347 | 2038 | 9207 | 0.8540 | 0.6239 | 0.3289 | 0.0000 |
| exp005b_srp_control_lrfix | wide2d_control | srp | 918 | 13074 | 4012 | 1952 | 174 | 6936 | 2910 | 8509 | 23237 | 0.6472 | 0.4894 | 0.3339 | 0.0000 |

`BPP(FP)` / `BPP(FN)` are RNA-macro means (one value per RNA, then averaged),
the convention consistent with the primary RNA-macro F1. The pair-count-weighted
pooled means are printed in each `<run>.md`; they can reverse the sign on long-RNA
folds (Simpson's paradox -- RNAs with many false positives produce low-BPP false
positives). Cite the RNA-macro numbers and state the weighting.

Per-run details: `<run>.json` / `<run>.md` in this directory.

