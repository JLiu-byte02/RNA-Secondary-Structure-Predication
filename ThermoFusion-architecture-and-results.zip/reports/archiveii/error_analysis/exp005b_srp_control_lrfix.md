# Error analysis -- exp005b_srp_control_lrfix (srp fold)

Paper arm: `wide2d_control`.

n = 918 RNAs; pairs recomputed from `runs/exp005b_srp_control_lrfix/predictions_srp.jsonl`.

## Pair level

| TP | FP | FN | pooled precision | pooled recall | pooled F1 | RNA-macro F1 |
| --- | --- | --- | --- | --- | --- | --- |
| 26601 | 8509 | 23237 | 0.7576 | 0.5337 | 0.6263 | 0.6472 |

## Stem level

| ref stems | pred stems | exact | truncated | fragmented | missing | spurious stems | pooled stem F1 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 13074 | 9214 | 4012 | 1952 | 174 | 6936 | 2910 | 0.6263 |

| metric | RNA-macro | pooled |
| --- | --- | --- |
| exact-stem fraction | 0.4042 | 0.3069 |
| missing-stem fraction | 0.4451 | 0.5305 |
| fragmented-stem fraction | 0.0153 | 0.0133 |
| spurious-stem rate | 3.1699 | 0.3158 |

## Boltzmann-ensemble support of FP vs FN pairs

|  | TP | FP | FN |
| --- | --- | --- | --- |
| mean BPP (pair-weighted) | 0.7372 | 0.3617 | 0.4571 |
| mean BPP (RNA-macro) | 0.7153 | 0.4894 | 0.3339 |
| fraction BPP >= 0.5 (RNA-macro) | - | 0.5090 | 0.3350 |

Paired FP-vs-FN test over 809 RNAs with both error types: mean BPP(FP)-BPP(FN) = 0.1503; Wilcoxon p = 0.0000.

Cache: 918 sequences found, 0 missing under `data/thermo/all`.

## Input consistency

Predictions vs canonical dataset split: 918 / 918 records, missing ids 0, reference-pair mismatches 0 (passed).

