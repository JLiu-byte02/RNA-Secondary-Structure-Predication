# Error analysis -- exp005c_srp_bpp_lrfix (srp fold)

Paper arm: `wide2d_bpp`.

n = 918 RNAs; pairs recomputed from `runs/exp005c_srp_bpp_lrfix/predictions_srp.jsonl`.

## Pair level

| TP | FP | FN | pooled precision | pooled recall | pooled F1 | RNA-macro F1 |
| --- | --- | --- | --- | --- | --- | --- |
| 28718 | 7863 | 21120 | 0.7851 | 0.5762 | 0.6646 | 0.6654 |

## Stem level

| ref stems | pred stems | exact | truncated | fragmented | missing | spurious stems | pooled stem F1 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 13074 | 9509 | 4419 | 2110 | 178 | 6367 | 2637 | 0.6646 |

| metric | RNA-macro | pooled |
| --- | --- | --- |
| exact-stem fraction | 0.4214 | 0.3380 |
| missing-stem fraction | 0.4250 | 0.4870 |
| fragmented-stem fraction | 0.0128 | 0.0136 |
| spurious-stem rate | 2.8725 | 0.2773 |

## Boltzmann-ensemble support of FP vs FN pairs

|  | TP | FP | FN |
| --- | --- | --- | --- |
| mean BPP (pair-weighted) | 0.7618 | 0.5185 | 0.3956 |
| mean BPP (RNA-macro) | 0.7422 | 0.5851 | 0.2845 |
| fraction BPP >= 0.5 (RNA-macro) | - | 0.6146 | 0.2847 |

Paired FP-vs-FN test over 820 RNAs with both error types: mean BPP(FP)-BPP(FN) = 0.3076; Wilcoxon p = 0.0000.

Cache: 918 sequences found, 0 missing under `data/thermo/all`.

## Input consistency

Predictions vs canonical dataset split: 918 / 918 records, missing ids 0, reference-pair mismatches 0 (passed).

