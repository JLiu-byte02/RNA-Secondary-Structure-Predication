# Error analysis -- exp003b_5s_official_bpp_s17 (5s fold)

Paper arm: `wide2d_bpp`.

n = 1283 RNAs; pairs recomputed from `runs/exp003b_5s_official_bpp_s17/predictions_5s.jsonl`.

## Pair level

| TP | FP | FN | pooled precision | pooled recall | pooled F1 | RNA-macro F1 |
| --- | --- | --- | --- | --- | --- | --- |
| 35555 | 2429 | 7569 | 0.9361 | 0.8245 | 0.8767 | 0.8716 |

## Stem level

| ref stems | pred stems | exact | truncated | fragmented | missing | spurious stems | pooled stem F1 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 11230 | 8641 | 6906 | 1235 | 36 | 3053 | 441 | 0.8767 |

| metric | RNA-macro | pooled |
| --- | --- | --- |
| exact-stem fraction | 0.6180 | 0.6150 |
| missing-stem fraction | 0.2693 | 0.2719 |
| fragmented-stem fraction | 0.0031 | 0.0032 |
| spurious-stem rate | 0.3437 | 0.0510 |

## Boltzmann-ensemble support of FP vs FN pairs

|  | TP | FP | FN |
| --- | --- | --- | --- |
| mean BPP (pair-weighted) | 0.7202 | 0.6999 | 0.1902 |
| mean BPP (RNA-macro) | 0.7041 | 0.6888 | 0.2044 |
| fraction BPP >= 0.5 (RNA-macro) | - | 0.7592 | 0.1492 |

Paired FP-vs-FN test over 1031 RNAs with both error types: mean BPP(FP)-BPP(FN) = 0.5040; Wilcoxon p = 0.0000.

Cache: 1283 sequences found, 0 missing under `data/thermo/all`.

## Input consistency

Predictions vs canonical dataset split: 1283 / 1283 records, missing ids 0, reference-pair mismatches 0 (passed).

