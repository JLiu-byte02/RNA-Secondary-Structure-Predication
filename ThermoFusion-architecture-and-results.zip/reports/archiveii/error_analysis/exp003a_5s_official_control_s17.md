# Error analysis -- exp003a_5s_official_control_s17 (5s fold)

Paper arm: `wide2d_control`.

n = 1283 RNAs; pairs recomputed from `runs/exp003a_5s_official_control_s17/predictions_5s.jsonl`.

## Pair level

| TP | FP | FN | pooled precision | pooled recall | pooled F1 | RNA-macro F1 |
| --- | --- | --- | --- | --- | --- | --- |
| 33917 | 2038 | 9207 | 0.9433 | 0.7865 | 0.8578 | 0.8540 |

## Stem level

| ref stems | pred stems | exact | truncated | fragmented | missing | spurious stems | pooled stem F1 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 11230 | 7871 | 6181 | 1301 | 28 | 3720 | 347 | 0.8578 |

| metric | RNA-macro | pooled |
| --- | --- | --- |
| exact-stem fraction | 0.5512 | 0.5504 |
| missing-stem fraction | 0.3310 | 0.3313 |
| fragmented-stem fraction | 0.0026 | 0.0025 |
| spurious-stem rate | 0.2705 | 0.0441 |

## Boltzmann-ensemble support of FP vs FN pairs

|  | TP | FP | FN |
| --- | --- | --- | --- |
| mean BPP (pair-weighted) | 0.7022 | 0.6183 | 0.3509 |
| mean BPP (RNA-macro) | 0.6959 | 0.6239 | 0.3289 |
| fraction BPP >= 0.5 (RNA-macro) | - | 0.6659 | 0.3147 |

Paired FP-vs-FN test over 991 RNAs with both error types: mean BPP(FP)-BPP(FN) = 0.3197; Wilcoxon p = 0.0000.

Cache: 1283 sequences found, 0 missing under `data/thermo/all`.

## Input consistency

Predictions vs canonical dataset split: 1283 / 1283 records, missing ids 0, reference-pair mismatches 0 (passed).

