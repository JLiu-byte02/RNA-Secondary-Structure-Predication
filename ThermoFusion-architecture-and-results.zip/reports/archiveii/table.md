# ArchiveII fold table vs official RiNALMo

Generated: 2026-10-30T07:11:57+08:00 by `scripts/analysis/collect_folds.py`.

Every row is recomputed from the run's per-RNA prediction file and checked against its own `metrics.json` (see the checks section); deltas are `ours - official`.

Official constants: `.recovered/model_init/RNA_ThermoFusion_model/research/audit/evidence/reports/archiveii_frozen_2026-10-22/family_results.csv` (mode `RiNALMo_official`, source `audit_snapshot`, sha256 `fa43b712cf719d436dc90e2a5294ac9f150ad2d6432f116dea6b333050d779b2`).

## Per-family rows (ours vs official)

| run | method | protocol | family | n | exact F1 | flex F1* | official-flex F1 | official exact | official flex* | Δexact | Δoff-flex | seed | head | BPP | thr | best ep |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| exp000a_5s_official_s17 | official_recipe | base_lr(1e-5) | 5s | 1283 | 0.8272 | 0.8369 | 0.8376 | 0.8772 | 0.8842 | -0.0500 | -0.0466 | 17 | outer_product | no | 0.1100 | 14 |
| exp007a_5s_official_lrfix | official_recipe_lrfix | current_lr(1e-6) | 5s | 1283 | 0.8121 | 0.8201 | 0.8193 | 0.8772 | 0.8842 | -0.0651 | -0.0649 | 17 | outer_product | no | 0.2400 | 15 |
| method_bpp_16s | wide2d_bpp | base_lr(1e-5) | 16s | 67 | 0.7518 | 0.7619 | 0.7594 | 0.7303 | 0.7371 | 0.0215 | 0.0223 | 17 | wide2d | yes | 0.0800 | 14 |
| method_bpp_23s | wide2d_bpp | base_lr(1e-5) | 23s | 15 | 0.8717 | 0.8848 | 0.8861 | 0.8383 | 0.8464 | 0.0335 | 0.0396 | 17 | wide2d | yes | 0.1600 | 14 |
| exp003b_5s_official_bpp_s17 | wide2d_bpp | base_lr(1e-5) | 5s | 1283 | 0.8716 | 0.8850 | 0.8858 | 0.8772 | 0.8842 | -0.0056 | 0.0016 | 17 | wide2d | yes | 0.0700 | 15 |
| method_bpp_5s | wide2d_bpp | base_lr(1e-5) | 5s | 1283 | 0.8653 | 0.8763 | 0.8773 | 0.8772 | 0.8842 | -0.0119 | -0.0069 | 17 | wide2d | yes | 0.1000 | 15 |
| method_bpp_RNaseP_v2 | wide2d_bpp | base_lr(1e-5) | RNaseP | 454 | 0.7892 | 0.8057 | 0.8058 | 0.7833 | 0.7985 | 0.0059 | 0.0073 | 17 | wide2d | yes | 0.1000 | 12 |
| method_bpp_grp1 | wide2d_bpp | base_lr(1e-5) | grp1 | 74 | 0.6708 | 0.6947 | 0.6927 | 0.6391 | 0.6566 | 0.0317 | 0.0362 | 17 | wide2d | yes | 0.0900 | 15 |
| exp005c_srp_bpp_lrfix | wide2d_bpp | current_lr(1e-6) | srp | 918 | 0.6654 | 0.7102 | 0.6970 | 0.6691 | 0.6996 | -0.0037 | -0.0027 | 17 | wide2d | yes | 0.1300 | 15 |
| method_bpp_srp | wide2d_bpp | base_lr(1e-5) | srp | 918 | 0.6432 | 0.6839 | 0.6767 | 0.6691 | 0.6996 | -0.0259 | -0.0229 | 17 | wide2d | yes | 0.0900 | 15 |
| method_bpp_tRNA | wide2d_bpp | base_lr(1e-5) | tRNA | 557 | 0.9438 | 0.9477 | 0.9478 | 0.9303 | 0.9313 | 0.0135 | 0.0165 | 17 | wide2d | yes | 0.1300 | 15 |
| method_bpp_telomerase | wide2d_bpp | base_lr(1e-5) | telomerase | 35 | 0.2737 | 0.3099 | 0.3028 | 0.1173 | 0.1201 | 0.1565 | 0.1827 | 17 | wide2d | yes | 0.1400 | 15 |
| method_bpp_tmRNA | wide2d_bpp | base_lr(1e-5) | tmRNA | 462 | 0.7460 | 0.7753 | 0.7756 | 0.7680 | 0.8004 | -0.0220 | -0.0249 | 17 | wide2d | yes | 0.1300 | 15 |
| exp003a_5s_official_control_s17 | wide2d_control | base_lr(1e-5) | 5s | 1283 | 0.8540 | 0.8644 | 0.8654 | 0.8772 | 0.8842 | -0.0232 | -0.0188 | 17 | wide2d | no | 0.1200 | 15 |
| exp005b_srp_control_lrfix | wide2d_control | current_lr(1e-6) | srp | 918 | 0.6472 | 0.6867 | 0.6758 | 0.6691 | 0.6996 | -0.0219 | -0.0238 | 17 | wide2d | no | 0.1100 | 15 |

`flex F1*` is our one-to-one shift-1 flexible metric; `official-flex F1` is the published RiNALMo convention, which is the only flexible number comparable to the official column.

## Method aggregates (available folds only)

| method | folds | protocols | n | eq-family exact | eq-family off-flex | RNA-w exact | RNA-w off-flex | official eq exact | official eq flex | Δeq exact | Δeq off-flex | coverage |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| official_recipe | 1 | base_lr(1e-5) | 1283 | 0.8272 | 0.8376 | 0.8272 | 0.8376 | 0.8772 | 0.8842 | -0.0500 | -0.0466 | partial coverage: 1/9 folds; missing 16s,23s,tRNA,srp,tmRNA,RNaseP,grp1,telomerase |
| official_recipe_lrfix | 1 | current_lr(1e-6) | 1283 | 0.8121 | 0.8193 | 0.8121 | 0.8193 | 0.8772 | 0.8842 | -0.0651 | -0.0649 | partial coverage: 1/9 folds; missing 16s,23s,tRNA,srp,tmRNA,RNaseP,grp1,telomerase |
| wide2d_bpp | 9 | base_lr(1e-5),current_lr(1e-6) | 3865 | 0.7300 | 0.7487 | 0.7933 | 0.8123 | 0.7059 | 0.7194 | 0.0241 | 0.0294 | all 9 folds |
| wide2d_control | 2 | base_lr(1e-5),current_lr(1e-6) | 2201 | 0.7506 | 0.7706 | 0.7677 | 0.7863 | 0.7731 | 0.7919 | -0.0226 | -0.0213 | partial coverage: 2/9 folds; missing 16s,23s,tRNA,tmRNA,RNaseP,grp1,telomerase |

> **Protocol heterogeneity:** a method marked with more than one protocol mixes different gradual-unfreezing entry-lr semantics across folds. Within-fold comparisons are still matched, but cross-fold means are descriptive only.

### Protocol-homogeneous slices

| method @ protocol | folds | n | eq-family exact | eq-family off-flex | Δeq exact |
| --- | --- | --- | --- | --- | --- |
| official_recipe @ base_lr(1e-5) | 1 | 1283 | 0.8272 | 0.8376 | -0.0500 |
| official_recipe_lrfix @ current_lr(1e-6) | 1 | 1283 | 0.8121 | 0.8193 | -0.0651 |
| wide2d_bpp @ base_lr(1e-5) | 9 | 3865 | 0.7287 | 0.7476 | 0.0229 |
| wide2d_bpp @ current_lr(1e-6) | 1 | 918 | 0.6654 | 0.6970 | -0.0037 |
| wide2d_control @ base_lr(1e-5) | 1 | 1283 | 0.8540 | 0.8654 | -0.0232 |
| wide2d_control @ current_lr(1e-6) | 1 | 918 | 0.6472 | 0.6758 | -0.0219 |

## Verification checks (recomputed vs run metrics.json)

| run | n | exact Δ | flex Δ | off-flex Δ | stored per-RNA | passed |
| --- | --- | --- | --- | --- | --- | --- |
| exp000a_5s_official_s17 | 1283 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| exp003a_5s_official_control_s17 | 1283 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| exp003b_5s_official_bpp_s17 | 1283 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| exp005b_srp_control_lrfix | 918 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| exp005c_srp_bpp_lrfix | 918 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| exp007a_5s_official_lrfix | 1283 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_16s | 67 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_23s | 15 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_5s | 1283 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_RNaseP_v2 | 454 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_grp1 | 74 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_srp | 918 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_tRNA | 557 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_telomerase | 35 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |
| method_bpp_tmRNA | 462 | 0.000000000000 | 0.000000000000 | 0.000000000000 | 0 | yes |

> Coverage is partial by construction: only folds whose run directory exists are reported. The official 9-fold equal-family bar is exact 0.705871 / flexible 0.719373; do not compare a partial-coverage aggregate to it without stating the missing folds.

## Provenance

| run | family | source | metrics sha256 | predictions sha256 |
| --- | --- | --- | --- | --- |
| exp000a_5s_official_s17 | 5s | server | 9682e942062bfa17badff4dabc63983421efe0fdf417679e2a65528b1818ba4a | b0ecbbd80de909f1d6e9933fd49ec3e616e4eb86996a87f1cd011cd6e5d05c90 |
| exp007a_5s_official_lrfix | 5s | server | d2938537bc11afb1942181c6eb042b448c0619e8d1be63342aac03e942a6e39a | 6222ac7ff29228a336f9a235e4403f4c1ce72b77a9497dd5eb3464d25a9dde71 |
| method_bpp_16s | 16s | server | 5b0d866c737019eeb370bb8d77008089ea03f816da08d37359149c1781440f35 | 2e068feed2f637e5e34ac07e5d1a441bb66c9f2a33acc18302345d2b66192258 |
| method_bpp_23s | 23s | server | 37056e69ba3d0cb19d52f18cd785898bec9579f722b26a9c849777da7ecbaace | 4610fd8f952df2e4ce63b9701171d7450674649a70d1f4c763c6d5cdcc8cf2a4 |
| exp003b_5s_official_bpp_s17 | 5s | server | 8e2e9116c7b6bd9830432d13defde8eb15e7d14ce5b8b3e240eb8287062e62e0 | c58163bb626c13b02d08c01f984ce50553409cf71ee8109ab7c971284bfd9c2b |
| method_bpp_5s | 5s | server | 1d8674fa2765f77183f584ea8a394f5b45ef375a92a0cb9b858fde54d58dae03 | 905a1efaaa6bcc1160b8f9d8321de0fd5e301939794a95b44cc95e81e9279236 |
| method_bpp_RNaseP_v2 | RNaseP | server | de275a922806d2332dad2381e374ade9897a0406abcfff5ea6ae523df1523630 | 3bd1409f4d69902f5f41ff3eb9b197e46575435ed24590cbee96a15f777549b2 |
| method_bpp_grp1 | grp1 | server | 08c356cfd4bf7e8f1d54122f9505b01b06f345d6aeef8f5ba714de8ffd2d6ebb | 1c10b76f4fce33999870587640e15fd250690a69f34201955ee614d0c1be6306 |
| exp005c_srp_bpp_lrfix | srp | server | f371391d2391d81a0f60a7be7766016e818c6a5be6a825a88ade4e66469e0923 | 5999c032c1544007cf4a4f47cd999b1f8eec87cc714e9f177d6435bcc4d12d18 |
| method_bpp_srp | srp | server | 81427dc3bd273049fb0eab2496b61adf45d7462440e7627197c197646c2ddf97 | caa1d691256b1e64cb6a11ddd795ef74fe7a6f539d5e8b31c91a2cd71071fdd1 |
| method_bpp_tRNA | tRNA | server | 1724abe59fbedc5b60e5f42c9b96fce08318fa98860379b4969081dc00f2b271 | b28917b8313f26650763429d8071fe598cd74d5b16c6e483ad208476e8a30499 |
| method_bpp_telomerase | telomerase | server | 601e2f09b42f9556a0051d47f0cba4bbc4cbf81283921e4208f48384d05abc75 | 61b812c7a6aaf9cd0e589b9fe594dee14ad3008ed490701e3a73d62fe067b82d |
| method_bpp_tmRNA | tmRNA | server | b7817093c357121f133a8438f386a375651c1ef2df535c4a8e23dc56408346db | 10ac667c7adefe7e5b346669b8c498b17853ba0f5acdc011c49cd8f63095d338 |
| exp003a_5s_official_control_s17 | 5s | server | 90774a9359be16623c038fccadb0cf613d28651c7c56b9fe8c9fc44faa128997 | 72551da2071ca8bb51f8311f5008ec22ea5e0bc005ff4d1956f8a527125e5a4e |
| exp005b_srp_control_lrfix | srp | server | f1b947222e89a05088fdeb2ac1e4ba977906f4e2205f971f1afa87c4554c855f | 7fd0932f92d83d8287fe645d2d950826e10fb96b1bfbfc297f8dd6031c698660 |

## Runs not included

| run | reason | detail |
| --- | --- | --- |
| method_bpp_RNaseP | not_completed | run 'method_bpp_RNaseP' is not completed (status='running'); exclude it or pass --allow-incomplete |

