# RNA ThermoFusion — ablation and multi-seed report

Status: **final**, 2026-11-06. All planned runs (core 2x2, zero-BPP, equal-capacity,
soup/inference matrix, channel/thermo-form ablations, three seeds, ArchiveII control
retrains) have completed. All numbers are per-RNA test metrics with no test-time tuning.
Exact F1 is primary; "off-flex" is the official RiNALMo flexible F1.

## 1. Executive summary

- **Main result reproduced with the real flash-attn kernel**: ArchiveII nine-fold
  leave-one-family-out, ThermoFusion + 3-epoch soup reaches equal-family exact
  **0.74524** vs 0.70588 for the released official checkpoints (**+3.94 pp**,
  fixed-reference 95% CI [+3.03, +4.81]; flexible **+4.41 pp** [+3.50, +5.30]).
  The archived result was 0.74430/+3.84 pp, so the main number is stable to 0.1 pp.
- **BPP is causal, not capacity**: a matched zero-BPP control tracks the no-BPP
  control to ≤0.7 pp, while turning BPP on gives +0.44 pp TS0 exact and
  **+7.9 pp bpRNA-new exact**. A 6-block no-BPP head (parameter-matched to the wide
  head) does not reproduce the gain.
- **Soup is a real, low-cost inference gain** on both branches (+1.6 pp TS0 exact)
  and is significantly positive on 6/9 ArchiveII folds in a true paired test;
  a 5-epoch soup (11–15) is better than the original 3-epoch window on both test sets.
- **TTA is not a free win**: it trades ~5.6 pp in-distribution for ~3 pp OOD. The
  probability ensemble is worse than soup on TS0 but better OOD. No inference
  strategy dominates both distributions; the report states this trade-off.
- **tmRNA is the only regressing family vs official** (−0.69 pp). Its reference pairs
  are 57.7% pseudoknotted, and the pseudoknot-free ViennaRNA prior assigns much lower
  BPP to crossing pairs. This is a mechanism-level explanation, not an excuse.
- **Honest defeats**: pure ViennaRNA centroid still beats the fine-tuned model on
  bpRNA-new (0.6302 vs 0.5225) and remains the best single predictor on telomerase
  (0.4893 vs 0.3200). We report them.
- **Surprising negative**: on TR0, removing `S0` (+1.04 pp), removing distance
  (+0.77 pp) or using BPP-only (+0.92 pp) all beat the full four-channel head on TS0;
  binary MFE is statistically indistinguishable from continuous BPP. The causal
  contribution is the thermodynamic pairing channel, not the four-channel design.

## 2. Data and protocol

- **ArchiveII**: canonical CT splits, nine leave-one-family-out folds. Threshold and
  epoch are selected on the validation split; the held-out family is evaluated once.
  Metrics: per-RNA exact F1 and official flexible F1; equal-family and RNA-weighted
  means.
- **bpRNA**: TR0 train (10,814), VL0 select (1,300), TS0 (1,305) and bpRNA-new (5,401)
  test. Threshold selected on VL0 only.
- **Model**: RiNALMo-Giga (650M, 33 blocks) fine-tuned with the official 15-epoch
  gradual-unfreezing recipe; wide 2D pair head with `[s0, BPP, distance, mask]`,
  4 blocks, 64 channels, zero-initialised residual; uniform weight soup over late
  epoch checkpoints. Decoding: canonical-pair + min-loop masks, greedy conflict
  resolution.
- **No test-time tuning.** Every diagnostic threshold/TTA/window row is labelled as
  such. Reused weights/data and the full artifact map are in §12.

## 3. Main nine-fold result

| metric | ThermoFusion + soup | official RiNALMo | Δ | fixed-ref 95% CI |
|---|---:|---:|---:|---:|
| equal-family exact | **0.74524** | 0.70588 | **+3.94 pp** | [+3.03, +4.81] |
| equal-family off-flex | **0.76348** | 0.71936 | **+4.41 pp** | [+3.50, +5.30] |
| RNA-weighted exact | 0.80690 | 0.79720 | +0.97 pp | — |
| RNA-weighted off-flex | 0.82558 | 0.81308 | +1.22 pp | — |

Per-fold exact deltas vs official: 5s +0.27, 16s +2.89, 23s +3.72, tRNA +1.84,
srp +1.28, **tmRNA −0.69**, RNaseP +0.39, grp1 +4.95, telomerase +20.78 pp. Eight of
nine folds are positive.

Single-best (no soup) archive result: equal-family exact 0.72839 vs 0.70588
(+2.25 pp, fixed-reference CI [+1.33, +3.13]); flexible +2.78 pp [+1.86, +3.67];
RNA-weighted exact −0.39 pp. The soup is what makes the RNA-weighted aggregate
positive.

## 4. Core component ablation on bpRNA TR0 (single seed 17)

All rows use the same data/recipe/decoding and differ only in the head/BPP.

| configuration | best ep | τ | TS0 exact | TS0 off-flex | bpRNA-new exact | bpRNA-new off-flex |
|---|---:|---:|---:|---:|---:|---:|
| Seq-Only, official 2-block head | 15 | 0.05 | 0.69651 | 0.74597 | 0.39918 | 0.41382 |
| Seq-Only, head-matched wide2d, no BPP | 13 | 0.13 | 0.69654 | 0.74664 | 0.43674 | 0.44983 |
| Zero-BPP (same params, BPP zeroed) | 15 | 0.08 | 0.69963 | 0.75178 | 0.44336 | 0.45877 |
| Deep Seq-Only, 6-block outer head | 15 | 0.09 | 0.69510 | 0.74864 | 0.40808 | — |
| **ThermoFusion (BPP on)** | 15 | 0.07 | **0.70404** | **0.76313** | **0.52248** | **0.54967** |
| Seq-Only + soup 13–15 | 13 | 0.13 | 0.7122 | — | 0.4443 | — |
| Seq-Only + soup 11–15 | 13 | 0.13 | 0.7125 | — | 0.4563 | — |
| **ThermoFusion + soup 13–15** | 15 | 0.07 | 0.7198 | — | 0.5563 | — |
| **ThermoFusion + soup 11–15** | 15 | 0.07 | **0.7215** | — | **0.5667** | — |

Decomposition:

- **Head upgrade** (official 2-block → wide2d, no BPP): TS0 0.00 pp, bpRNA-new
  **+3.76 pp**. The wide head is an OOD-robustness component, not a capacity win.
- **BPP** (wide2d no-BPP → ThermoFusion): TS0 **+0.75 pp**, bpRNA-new **+8.57 pp**
  exact (flexible +9.98 pp). Against the zero-BPP control: +0.44 pp / +7.91 pp.
- **Capacity control**: the 6-block outer head has 434,817 parameters vs 435,202 for
  the wide head (Δ 385, 0.09%). It reaches 0.6951/0.4081, i.e. it does **not** explain
  the method's gain.
- **Soup** adds +1.6 pp TS0 exact on both branches; the 5-epoch window (11–15) is
  better than 13–15 on both test sets (post-hoc window sensitivity, frozen threshold).

### 4.1 ArchiveII control retrains (sensitivity analysis, with a protocol caveat)

Six matched no-BPP controls were retrained with the same non-flash implementation used by
the new TR0 runs. The control retrains are **systematically weaker than the archived
flash-trained controls** on the hard folds (srp, RNaseP, tRNA, tmRNA), so this table is a
sensitivity analysis, not a replacement for the archived BPP ablation:

| fold | control best | control soup 13–15 | method soup (flash) | Δ soup |
|---|---:|---:|---:|---:|
| 5s | 0.85467 | 0.86164 | 0.87989 | +1.83 pp |
| srp | 0.57697 | 0.57385 | 0.68193 | +10.81 pp |
| RNaseP | 0.71145 | 0.73276 | 0.78723 | +5.45 pp |
| tRNA | 0.92190 | 0.91905 | 0.94865 | +2.96 pp |
| telomerase | 0.12466 | 0.13024 | 0.32511 | +19.49 pp |
| tmRNA | 0.69601 | 0.70064 | 0.76106 | +6.04 pp |

The direction is consistent with the archived controls (BPP positive on every fold except
tmRNA vs official), but the magnitude is inflated by the weaker control retrains. The
paper's primary BPP attribution should remain the archived matched controls
(5s +1.13, srp +1.82, RNaseP +1.87, tRNA +0.23, tmRNA −0.11, telomerase +17.07 pp, all
flash-trained), with this table disclosed as a robustness check. On 5s, where the old and
new controls agree (0.8540 vs 0.8547), the two protocols agree.

## 5. Inference-strategy ablation (TR0)

| variant | Thermo TS0 | Thermo bpRNA-new | Seq TS0 | Seq bpRNA-new |
|---|---:|---:|---:|---:|
| best checkpoint | 0.7041 | 0.5223 | 0.6968 | 0.4370 |
| soup 14–15 | 0.7162 | 0.5442 | 0.7075 | 0.4335 |
| soup 13–15 | 0.7198 | 0.5563 | 0.7122 | 0.4443 |
| **soup 11–15** | **0.7215** | **0.5667** | **0.7125** | **0.4563** |
| soup 13–15, fixed τ=0.13 | 0.7224 | 0.5480 | 0.7122 | 0.4443 |
| probability ensemble 13–15 | 0.7141 | 0.5776 | 0.7085 | 0.4604 |
| soup 13–15 + RC TTA | 0.6636 | **0.5892** | 0.6575 | 0.4643 |

- The validation-selected best epoch is not the best on TS0 (epoch 14) or OOD
  (epoch 13); soup is a stable compromise.
- Fixed τ helps TS0 slightly but hurts OOD; per-fold validation thresholds remain the
  protocol.
- TTA costs 5.6 pp TS0 and gains 2–3 pp OOD; probability ensemble costs 3× inference
  and is worse than soup on TS0. No strategy dominates both.

## 6. Statistics

### 6.1 What the archive supports

Official per-RNA predictions exist only for 5s; the nine-fold archive stores fold-level
official means. Therefore the nine-fold CI is a **fixed-reference stratified
bootstrap** (10,000 resamples within each family), not a paired test. The only true
paired tests vs official are on 5s.

### 6.2 Fold-level sign test

| comparison | positive folds | two-sided p |
|---|---:|---:|
| single-best vs official | 6 / 9 | 0.51 (descriptive) |
| soup vs official | 8 / 9 | **0.039** |

### 6.3 True paired test on 5s (n = 1,283)

| comparison | metric | Δ | 95% CI | Wilcoxon p |
|---|---|---:|---:|---:|
| single-best vs official | exact | −1.19 pp | [−1.56, −0.83] | 9.6e−14 |
| single-best vs official | flexible | −0.75 pp | [−1.11, −0.38] | 5.4e−07 |
| **soup vs official** | exact | +0.27 pp | [−0.11, +0.66] | 0.868 |
| **soup vs official** | flexible | **+0.73 pp** | [+0.35, +1.12] | **0.0032** |

The nine-fold win is not driven by 5s; soup closes 5s exact to a tie and is
significantly better on flexible.

### 6.4 True paired soup vs single-best (all nine folds)

Soup is significantly positive on 6/9 folds (5s +1.46, srp +3.87, tmRNA +1.51,
telomerase +5.14, grp1 +1.78, tRNA +0.48 pp; all p<1e−5 except 16s p=0.003), neutral on
23s (+0.37, p=0.55) and RNaseP (−0.19, p=0.42), and never significantly negative.
Source: `reports/archiveii/soup_flash_stats.json`.

## 7. Why tmRNA regresses: pseudoknots

| split | crossing reference pairs | mean BPP nested | mean BPP crossing |
|---|---:|---:|---:|
| 5s / tRNA / srp | 0.0% | 0.63 / 0.65 / 0.61 | — |
| bpRNA-new | 0.0% | 0.673 | — |
| 16s | 3.5% | 0.562 | 0.416 |
| 23s | 1.2% | 0.698 | 0.257 |
| grp1 | 12.4% | 0.613 | 0.318 |
| RNaseP | 23.7% | 0.618 | 0.335 |
| telomerase | 27.1% | 0.554 | 0.443 |
| **tmRNA** | **57.7%** | **0.512** | **0.354** |

tmRNA is the only fold where the majority of reference pairs are pseudoknotted, and it
is the only family that regresses vs official. The physics prior is being asked a
question it cannot represent. Source: `scripts/analysis/bpp_support.py`.

### 7.1 Error analysis supports the same mechanism

On 5s, false positives carry high BPP (RNA-macro mean 0.6888) and false negatives low
BPP (0.2044); the same ordering holds on srp (0.5851 vs 0.2845, Wilcoxon p<1e−4). The
model's residual errors sit where the Boltzmann ensemble is also uncertain, exactly the
signal the fusion head is meant to exploit.

## 8. Pure-ViennaRNA floor

| dataset | MFE | centroid | MEA | ThermoFusion + soup |
|---|---:|---:|---:|---:|
| bpRNA TS0 | 0.4915 | 0.5091 | 0.5035 | 0.7198 |
| bpRNA-new | 0.6166 | **0.6302** | 0.6254 | 0.5563 |
| ArchiveII macro | 0.5625 | **0.5867** | 0.5791 | 0.7452 |

The method beats pure centroid on 8/9 ArchiveII folds; telomerase is the exception
(centroid 0.4893 vs method 0.3200), and on bpRNA-new pure centroid is still ahead.
These are reported as the physics floor, not hidden.

## 9. Multi-seed (TR0, 3 seeds per configuration)

| configuration | TS0 exact values | TS0 mean ± std | bpRNA-new mean ± std |
|---|---|---:|---:|
| Seq-Only | 0.69654, 0.69067, 0.69259 | **0.6933 ± 0.0024** | 0.4412 ± 0.0123 |
| ThermoFusion | 0.70404, 0.71351, 0.71056 | **0.7094 ± 0.0040** | 0.5323 ± 0.0070 |

Seed spread is 0.24–0.40 pp on TS0, well below the 1.6 pp method–control gap: the
BPP effect survives initialization/shuffle variance. On bpRNA-new the ThermoFusion
gain is +9.1 pp over Seq-Only at the mean level, but Seq-Only's OOD variance is
larger (1.2 pp vs 0.7 pp), so the OOD gain must be reported with both mean and std.
ArchiveII remains single-seed per fold; this experiment quantifies training variance
but does not turn the nine-fold result into a multi-seed estimate.

## 10. Fusion-channel and thermodynamic-form ablation

| variant | TS0 exact | bpRNA-new exact | Δ vs full method (TS0 / OOD) |
|---|---:|---:|---:|
| ThermoFusion (all channels) | 0.70404 | 0.52248 | — |
| w/o S0 (base logits) | **0.71447** | **0.52790** | **+1.04 / +0.54 pp** |
| w/o distance | **0.71176** | **0.55361** | **+0.77 / +3.11 pp** |
| MFE-replaced (BPP → binary MFE) | **0.71064** | **0.52632** | **+0.66 / +0.38 pp** |
| w/o mask | **0.71419** | **0.53633** | **+1.02 / +1.39 pp** |
| BPP-only (only BPP channel) | **0.71324** | 0.51851 | **+0.92 / −0.40 pp** |
| multi-thermo `[s0,bpp,mfe,mea,distance,mask]` | **0.71438** | **0.54478** | **+1.03 / +2.23 pp** |

**Falsified expectation:** the checklist predicted that removing the `S0` channel would
degrade most. On the matched TR0 run **every** auxiliary-channel removal improves TS0:
w/o S0 +1.04, w/o distance +0.77, w/o mask +1.02, BPP-only +0.92 pp; the distance
removal is also +3.11 pp OOD. This is a genuine negative result for the original design
intuition — the zero-initialised residual head learns the correction without the
auxiliary/base signals, and feeding them may overfit. It is reported as-is; the paper
should not claim that the four-channel design is necessary. The one caveat is that each
channel-drop row is a single seed. The **thermodynamic feature family is the only component that is
necessary in the current evidence** (zero-BPP collapses to the no-BPP control), while
the specific input set is not settled; the continuous-BPP representation is **not**
supported as superior to binary MFE:
replacing BPP by binary MFE gives 0.71064/0.52632, i.e. +0.66/+0.38 pp vs the full method,
inside one seed standard deviation. The honest claim is "thermodynamic pairing information
helps", not "continuous Boltzmann probabilities are required".

The multi-thermo head (`bpp+mfe+mea`) is the best single-seed balance on TS0
(0.71438) and second-best OOD (0.54478), while every auxiliary-channel removal also beats
the full head. The consistent reading is: **the thermodynamic features are the
contribution; the four-channel design (S0/distance/mask) is not.** BPP-only loses OOD
(−0.40 pp), so continuous/multi-feature thermodynamics still matters OOD; the natural
next model is `[bpp,mfe,mea]` without S0/distance/mask, which was not run. The
single-seed evidence does **not** justify replacing the main nine-fold model without an
ArchiveII re-run. Pure MFE/centroid/MEA structure scores are in §8; the ArchiveII control
sensitivity is in §4.1.

## 11. Limitations

- The archived per-epoch checkpoints were deleted with the old server run directory;
  soup windows/ensembles are regenerated from the same frozen configs, not read from
  the original run dirs.
- The flash→native checkpoint conversion is not numerically equivalent for long folds
  (RoPE implementation difference); all reported soup numbers use the real flash-attn
  kernel. Conversion results are diagnostics only.
- ArchiveII is family-held-out, not clan-held-out; tRNA/tmRNA share an Rfam clan with
  training families. The RFC-CD clan-disjoint tier (110 RNAs) is the external check:
  TR0+BPP 0.6609 vs official bpRNA checkpoint 0.5253 (+13.6 pp).
- Official per-RNA predictions are available only for 5s; nine-fold CIs are
  fixed-reference, and the report labels them as such.
- Single seed per ArchiveII fold; TR0 multi-seed is the variance estimate. Every
  channel-drop/BPP-only/MFE row is a single seed. The 0.4 pp seed std means 0.5–1 pp
  differences are at the edge of noise; the +3.11 pp distance-removal OOD gain is
  larger but still not seed-replicated.
- The ArchiveII control retrains use the non-flash implementation and are
  systematically weaker than the archived flash controls on hard folds (§4.1). The
  primary BPP attribution therefore stays with the archived flash-trained controls;
  the new 2x2 is a sensitivity analysis, not a replacement.
- The simplified BPP-only head is not re-validated on the nine ArchiveII folds; no
  claim is made that it would beat the four-channel main model.
- The final line is not "the method is universally better": pure ViennaRNA remains
  better on bpRNA-new and telomerase. The supported claim is an in-distribution and
  family-held-out macro improvement, with a demonstrated pseudoknot failure mode.

## 12. Reproduction / artifacts

- New code: `scripts/analysis/{inference_ablation,prob_ensemble,paired_stats,soup_stats,bpp_support,pure_vienna}.py`,
  `scripts/convert_flash_to_native.py`, `scripts/sync_server_results.py`.
- Configs: `configs/ablations/*.yaml` (generated by `scripts/gen_ablation_configs.py`).
- Server runs: `/home/junxuanliu/projects/RNA_ThermoFusion_deepseek_op_v1/runs/`.
- Statistics: `reports/archiveii/soup_flash_stats.json`, `reports/STATS_SUMMARY.md`.
- Tables: `reports/ABLATION_TABLES_2026-11-05.md`, `reports/archiveii/table.md`.
- Main nine-fold artifacts: `reports/archiveii/soup_9fold.json`, `soup_flash_stats.json`.
- Flat result table for every completed run: `experiments/FINAL_RUN_SUMMARY.csv`.
- Synced server metrics/predictions: `experiments/server_sync_20261105/`.
- Delivery log: `docs/PUA_DELIVERY_LOG.md` (no ratings, no telemetry).

## 13. Claims supported by the evidence

1. **Supported**: on ArchiveII nine-fold LOFO, ThermoFusion + soup beats the released
   official checkpoints by +3.94 pp equal-family exact (fixed-reference 95% CI
   [+3.03, +4.81]) and +4.41 pp flexible; the result reproduces the archived 0.74430
   to 0.1 pp with the real flash kernel.
2. **Supported**: thermodynamic pairing information is causal. Zero-BPP collapses to
   the no-BPP control; turning BPP on gives +7.9 pp bpRNA-new exact over zero-BPP.
   The head-capacity control (6-block, parameter-matched) does not reproduce the gain.
3. **Supported**: weight soup is a cheap, general inference gain (+1.6 pp TS0 exact on
   both branches), significantly positive on 6/9 ArchiveII folds in a true paired test,
   and a 5-epoch window (11–15) is better than 3 epochs on both test sets.
4. **Supported with caveat**: on 5s the soup ties official on exact (+0.27 pp, p=0.87)
   and is significantly better on flexible (+0.73 pp, p=0.0032); the nine-fold win is
   driven by the other folds, not 5s.
5. **Not supported / honestly negative**: the full four-channel head is not necessary;
   S0/distance removal and BPP-only improve TS0, binary MFE matches continuous BPP, TTA
   trades ~5.6 pp in-distribution for ~3 pp OOD, and pure ViennaRNA still wins on
   bpRNA-new and telomerase. The paper must state the scope of the claim (ArchiveII
   family-held-out macro, in-distribution bpRNA) rather than "universally better".
