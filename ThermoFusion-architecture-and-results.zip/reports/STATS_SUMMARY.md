# Statistical validation summary (verified 2026-11-05)

All numbers below are computed from archived prediction/manifest files with
`scripts/analysis/paired_stats.py` (true paired rows) or copied from the frozen
`reports/archiveii/comparison.json` bootstrap record (fixed-reference rows). No
test-time tuning is involved.

## 1. What the archive can and cannot support

`comparison.json` records `bootstrap.mode = "fixed_reference_single_sample"` and
`official_per_rna_available = false`: the nine-fold archive stores only the official
**fold means**, not per-RNA official predictions. Therefore:

- a 10,000-resample **fixed-reference** bootstrap is valid for the difference of
  means; it is not a paired test;
- fold-level sign tests are valid;
- a true paired test is only possible on 5s, where the official per-RNA predictions
  were recovered from `.recovered/artifacts2/runs/eval_official_5s/`.

## 2. Nine-fold fixed-reference stratified bootstrap (exact / official-flexible)

| comparison | Δ exact | 95% CI | Δ flex | 95% CI |
|---|---:|---:|---:|---:|
| single-best ThermoFusion vs official | +2.25 pp | [+1.33, +3.13] | +2.78 pp | [+1.86, +3.67] |
| ThermoFusion + soup vs official | **+3.84 pp** | [+2.91, +4.70] | **+4.27 pp** | [+3.33, +5.13] |

Source: `reports/archiveii/comparison.json`, `reports/archiveii/soup_9fold.json`.

## 3. Fold-level sign test

| comparison | folds positive | two-sided binomial p |
|---|---:|---:|
| single-best vs official (exact) | 6 / 9 | 0.51 (descriptive) |
| ThermoFusion + soup vs official (exact) | 8 / 9 | **0.039** |

The soup is what turns the aggregate into a statistically defensible win at the fold level.

## 4. True paired tests on 5s (n = 1,283; official per-RNA available)

| comparison | metric | Δ | 95% CI | Wilcoxon p | sign p |
|---|---|---:|---:|---:|---:|
| single-best vs official | exact | −1.19 pp | [−1.56, −0.83] | 9.6e−14 | — |
| single-best vs official | flexible | −0.75 pp | [−1.11, −0.38] | 5.4e−07 | — |
| **soup vs official** | exact | +0.27 pp | [−0.11, +0.66] | 0.868 | 0.361 |
| **soup vs official** | flexible | **+0.73 pp** | [+0.35, +1.12] | **0.0032** | **0.016** |

Interpretation: on 5s the soup closes the exact-F1 gap (now a tie) and is significantly
better on the flexible metric, while the single-best model is significantly worse than
official on both. The nine-fold equal-family advantage comes from the other folds
(telomerase, tRNA, 16s, 23s, grp1) plus the soup, not from 5s.

## 5. Regenerated soup predictions (flash path, batch 1) — primary verification

The archived flash soup checkpoints were re-evaluated with the real flash-attn kernel and
batch size 1 (the conversion-to-native path is invalid for long folds; see
`docs/CHECKPOINT_2026-11-05_0130.md`). The regenerated nine-fold numbers:

| metric | regenerated soup | official | Δ | fixed-reference 95% CI |
|---|---:|---:|---:|---:|
| equal-family exact | 0.74524 | 0.70588 | **+3.94 pp** | [+3.03, +4.81] |
| equal-family official-flex | 0.76348 | 0.71936 | **+4.41 pp** | [+3.50, +5.30] |
| RNA-weighted exact | 0.80690 | 0.79720 | +0.97 pp | — |
| RNA-weighted official-flex | 0.82558 | 0.81308 | +1.22 pp | — |

This reproduces the archived 0.74430/+3.84 pp to +0.09 pp / +0.10 pp, so the main result is
not an artifact of the old batching/kernel. The CI is fixed-reference, not paired.

Per-fold soup-vs-official exact deltas: 5s +0.27, 16s +2.89, 23s +3.72, tRNA +1.84,
srp +1.28, tmRNA **−0.69**, RNaseP +0.39, grp1 +4.95, telomerase +20.78 pp. tmRNA remains the
only regression vs official, but the soup still improves tmRNA over its own single best.

### 5.1 True paired soup vs single-best (same checkpoint lineage, all 9 folds)

Because both the soup and single-best predictions exist per RNA for every fold, this is a
genuine paired comparison:

| fold | Δ exact | 95% CI | Wilcoxon p |
|---|---:|---:|---:|
| 5s | +1.46 pp | [+1.30, +1.62] | 3.7e−68 |
| 16s | +0.74 pp | [−0.00, +1.42] | 0.0030 |
| 23s | +0.37 pp | [−0.19, +1.06] | 0.55 |
| tRNA | +0.48 pp | [+0.29, +0.68] | 4.5e−06 |
| srp | +3.87 pp | [+3.40, +4.36] | 1.1e−64 |
| tmRNA | +1.51 pp | [+1.29, +1.72] | 1.6e−37 |
| RNaseP | −0.19 pp | [−0.49, +0.10] | 0.42 |
| grp1 | +1.78 pp | [+1.08, +2.52] | 4.1e−06 |
| telomerase | +5.14 pp | [+3.61, +6.66] | 4.4e−07 |

Soup is significantly positive on 6/9 folds, neutral on 2 (23s, RNaseP) and never
significantly negative. This is the cleanest evidence that weight soup is a real,
low-cost inference gain.

## 6. What must be stated in the paper

- Report the fixed-reference CI and the fold sign test; do not call them paired tests.
- Report the 5s paired result as the only true paired test available.
- Do not quote the nine-fold aggregate without the RNA-weighted number
  (single-best −0.39 pp, soup +0.96 pp), which answers a different question.
