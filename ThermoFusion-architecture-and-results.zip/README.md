# RNA-Secondary-Structure-Predication

ThermoFusion predicts RNA secondary structure using RiNALMo-Giga embeddings and ViennaRNA Boltzmann base-pair probabilities.

![ThermoFusion architecture](%E8%AE%BA%E6%96%87/fig1_architecture.png)

## Model architecture

The RiNALMo backbone encodes the RNA sequence. An outer-product pair head produces a base logit map. A 2D residual head combines that map with thermodynamic base-pair probabilities, relative distance, and a pair mask. Its zero-initialized output is added to the base logits, and the model produces symmetric pair scores.

- [PyTorch model implementation](src/model.py)
- [Architecture and ablation notes](reports/模型架构与消融结果简报.md)
- [Model and inference equations](reports/最终模型与推理数学公式.md)

The model implementation uses PyTorch. The full backbone requires the RiNALMo package and pretrained weights, which are external dependencies.

## Existing experimental results

In the ArchiveII nine-fold leave-one-family-out evaluation, the ThermoFusion checkpoint soup reached an equal-family exact F1 of **0.74430**. The released RiNALMo checkpoints, rescored under the same evaluation, reached **0.70588**, a difference of **3.84 percentage points**. See the report for the evaluation protocol, confidence intervals, and limitations.

- [Scientific report](reports/FINAL_REPORT.md)
- [ArchiveII per-family results](reports/archiveii/table.md)
- [Ablation tables](reports/ABLATION_TABLES_2026-11-05.md)
- [Completed experiment summary](experiments/FINAL_RUN_SUMMARY.csv)
